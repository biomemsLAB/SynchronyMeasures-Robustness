function [ HDF5Data ] = Matrix2HDF5( Matrix )
%MATRIX2HDF5 Summary of this function goes here
%   Detailed explanation goes here

h5create('')


end

