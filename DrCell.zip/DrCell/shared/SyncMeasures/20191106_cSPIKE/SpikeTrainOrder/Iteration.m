classdef Iteration

    properties
   
            Name;
            SpikeTrains;
            Order;
            SynfireIndicatorF;
            SynchronizationValueC;
            SynchronizationProfile;
            PairwiseMatrixD;
            TimeProfileE;
            SpikeTrainOrderSpikeValues;
            SpikeOrderSpikeValues;
            SpikeTrainOfASpike;        % TTTTTTTTTT
            
    end
    
end

