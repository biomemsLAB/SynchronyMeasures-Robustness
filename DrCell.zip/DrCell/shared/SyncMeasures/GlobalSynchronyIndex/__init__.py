from __future__ import absolute_import

from .global_sync import calc_global_sync, get_phase_spikes
