% plot ISI histogram (MC)

function [hp,hs]=plotISI_Histogram(logISI,hs,flag_getOnlyValues)

if nargin == 1
   flag_getOnlyValues = 0; % default: make plot 
   hs = subplot(1,1,1);
end
if nargin == 2
   flag_getOnlyValues = 0; % default: make plot
end

binEdges = -3:0.01:1;

if flag_getOnlyValues
    hp = histcounts(logISI,binEdges);
else
    hp=histogram(logISI,binEdges);
    hp.Parent.XLabel.String='log(ISI) in log(s)';
    hp.Parent.YLabel.String='Frequency';
end

end