function clientTaskCompleted(task,eventdata)
   disp(['Finished task: ' num2str(task.ID)])