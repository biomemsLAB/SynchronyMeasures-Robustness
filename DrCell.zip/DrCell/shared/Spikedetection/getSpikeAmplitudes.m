% Calculate spike amplitudes by means of raw data (M) and spike
% timestamps (TS)
%
function [AMPLITUDES]=getSpikeAmplitudes(raw,TS,SaRa,flag_isHDMEAmode)

    if nargin < 4
       flag_isHDMEAmode = 0; % default: no HDMEA mode 
    end
    
    AMPLITUDES=zeros(size(TS));
    SP = int32(TS*SaRa); % converting spike-timestamp to sample-position, consider sample offset of one sample later!
    for n=1:size(TS,2)
        adress=nonzeros(SP(:,n));
        if size(adress)~=0
            for k=1:size(adress)
                AMPLITUDES(k,n)=raw.M(adress(k)+1,n); % !!! +1 because M(0s)=not valid, 0s on index 1! -> Amplitude(1,60)=M(TS(1,60)*SaRa+1,60)
            end
        end
    end
    
    if flag_isHDMEAmode % convert values of amplitude if HDMEA data are used
        AMPLITUDES=digital2analog_sh(AMPLITUDES,raw);
        AMPLITUDES(AMPLITUDES==-4125)=0;
    end
end